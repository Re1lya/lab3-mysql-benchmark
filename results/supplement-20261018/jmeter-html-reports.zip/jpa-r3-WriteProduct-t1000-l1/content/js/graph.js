/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 8.0, "minX": 0.0, "maxY": 3015.0, "series": [{"data": [[0.0, 8.0], [0.1, 8.0], [0.2, 8.0], [0.3, 8.0], [0.4, 8.0], [0.5, 8.0], [0.6, 8.0], [0.7, 8.0], [0.8, 8.0], [0.9, 8.0], [1.0, 8.0], [1.1, 8.0], [1.2, 8.0], [1.3, 8.0], [1.4, 8.0], [1.5, 8.0], [1.6, 8.0], [1.7, 8.0], [1.8, 8.0], [1.9, 8.0], [2.0, 8.0], [2.1, 8.0], [2.2, 8.0], [2.3, 8.0], [2.4, 8.0], [2.5, 8.0], [2.6, 8.0], [2.7, 8.0], [2.8, 8.0], [2.9, 8.0], [3.0, 8.0], [3.1, 8.0], [3.2, 8.0], [3.3, 8.0], [3.4, 8.0], [3.5, 8.0], [3.6, 8.0], [3.7, 8.0], [3.8, 8.0], [3.9, 8.0], [4.0, 8.0], [4.1, 8.0], [4.2, 8.0], [4.3, 8.0], [4.4, 8.0], [4.5, 9.0], [4.6, 9.0], [4.7, 9.0], [4.8, 9.0], [4.9, 9.0], [5.0, 9.0], [5.1, 9.0], [5.2, 9.0], [5.3, 9.0], [5.4, 9.0], [5.5, 9.0], [5.6, 9.0], [5.7, 9.0], [5.8, 9.0], [5.9, 9.0], [6.0, 9.0], [6.1, 9.0], [6.2, 9.0], [6.3, 9.0], [6.4, 9.0], [6.5, 9.0], [6.6, 9.0], [6.7, 9.0], [6.8, 9.0], [6.9, 9.0], [7.0, 9.0], [7.1, 9.0], [7.2, 9.0], [7.3, 9.0], [7.4, 9.0], [7.5, 9.0], [7.6, 9.0], [7.7, 9.0], [7.8, 9.0], [7.9, 9.0], [8.0, 9.0], [8.1, 9.0], [8.2, 9.0], [8.3, 9.0], [8.4, 9.0], [8.5, 9.0], [8.6, 9.0], [8.7, 9.0], [8.8, 9.0], [8.9, 9.0], [9.0, 9.0], [9.1, 9.0], [9.2, 9.0], [9.3, 9.0], [9.4, 9.0], [9.5, 9.0], [9.6, 9.0], [9.7, 9.0], [9.8, 9.0], [9.9, 9.0], [10.0, 9.0], [10.1, 9.0], [10.2, 9.0], [10.3, 9.0], [10.4, 9.0], [10.5, 9.0], [10.6, 9.0], [10.7, 9.0], [10.8, 9.0], [10.9, 9.0], [11.0, 9.0], [11.1, 9.0], [11.2, 9.0], [11.3, 9.0], [11.4, 9.0], [11.5, 9.0], [11.6, 9.0], [11.7, 9.0], [11.8, 9.0], [11.9, 9.0], [12.0, 9.0], [12.1, 9.0], [12.2, 9.0], [12.3, 9.0], [12.4, 9.0], [12.5, 9.0], [12.6, 9.0], [12.7, 9.0], [12.8, 9.0], [12.9, 9.0], [13.0, 9.0], [13.1, 9.0], [13.2, 9.0], [13.3, 9.0], [13.4, 9.0], [13.5, 9.0], [13.6, 9.0], [13.7, 9.0], [13.8, 9.0], [13.9, 9.0], [14.0, 9.0], [14.1, 9.0], [14.2, 9.0], [14.3, 9.0], [14.4, 9.0], [14.5, 9.0], [14.6, 9.0], [14.7, 9.0], [14.8, 9.0], [14.9, 9.0], [15.0, 9.0], [15.1, 9.0], [15.2, 9.0], [15.3, 9.0], [15.4, 9.0], [15.5, 9.0], [15.6, 9.0], [15.7, 9.0], [15.8, 9.0], [15.9, 9.0], [16.0, 9.0], [16.1, 9.0], [16.2, 9.0], [16.3, 9.0], [16.4, 9.0], [16.5, 9.0], [16.6, 9.0], [16.7, 9.0], [16.8, 9.0], [16.9, 9.0], [17.0, 9.0], [17.1, 9.0], [17.2, 9.0], [17.3, 9.0], [17.4, 9.0], [17.5, 9.0], [17.6, 9.0], [17.7, 9.0], [17.8, 9.0], [17.9, 9.0], [18.0, 10.0], [18.1, 10.0], [18.2, 10.0], [18.3, 10.0], [18.4, 10.0], [18.5, 10.0], [18.6, 10.0], [18.7, 10.0], [18.8, 10.0], [18.9, 10.0], [19.0, 10.0], [19.1, 10.0], [19.2, 10.0], [19.3, 10.0], [19.4, 10.0], [19.5, 10.0], [19.6, 10.0], [19.7, 10.0], [19.8, 10.0], [19.9, 10.0], [20.0, 10.0], [20.1, 10.0], [20.2, 10.0], [20.3, 10.0], [20.4, 10.0], [20.5, 10.0], [20.6, 10.0], [20.7, 10.0], [20.8, 10.0], [20.9, 10.0], [21.0, 10.0], [21.1, 10.0], [21.2, 10.0], [21.3, 10.0], [21.4, 10.0], [21.5, 10.0], [21.6, 10.0], [21.7, 10.0], [21.8, 10.0], [21.9, 10.0], [22.0, 10.0], [22.1, 10.0], [22.2, 10.0], [22.3, 10.0], [22.4, 10.0], [22.5, 10.0], [22.6, 10.0], [22.7, 10.0], [22.8, 10.0], [22.9, 10.0], [23.0, 10.0], [23.1, 10.0], [23.2, 10.0], [23.3, 10.0], [23.4, 10.0], [23.5, 10.0], [23.6, 10.0], [23.7, 10.0], [23.8, 10.0], [23.9, 10.0], [24.0, 10.0], [24.1, 10.0], [24.2, 10.0], [24.3, 10.0], [24.4, 10.0], [24.5, 10.0], [24.6, 10.0], [24.7, 10.0], [24.8, 10.0], [24.9, 10.0], [25.0, 10.0], [25.1, 10.0], [25.2, 10.0], [25.3, 10.0], [25.4, 10.0], [25.5, 10.0], [25.6, 10.0], [25.7, 10.0], [25.8, 10.0], [25.9, 10.0], [26.0, 10.0], [26.1, 10.0], [26.2, 10.0], [26.3, 10.0], [26.4, 10.0], [26.5, 10.0], [26.6, 10.0], [26.7, 10.0], [26.8, 10.0], [26.9, 10.0], [27.0, 10.0], [27.1, 10.0], [27.2, 10.0], [27.3, 10.0], [27.4, 10.0], [27.5, 10.0], [27.6, 10.0], [27.7, 10.0], [27.8, 10.0], [27.9, 10.0], [28.0, 10.0], [28.1, 10.0], [28.2, 10.0], [28.3, 10.0], [28.4, 10.0], [28.5, 10.0], [28.6, 10.0], [28.7, 10.0], [28.8, 10.0], [28.9, 10.0], [29.0, 10.0], [29.1, 10.0], [29.2, 11.0], [29.3, 11.0], [29.4, 11.0], [29.5, 11.0], [29.6, 11.0], [29.7, 11.0], [29.8, 11.0], [29.9, 11.0], [30.0, 11.0], [30.1, 11.0], [30.2, 11.0], [30.3, 11.0], [30.4, 11.0], [30.5, 11.0], [30.6, 11.0], [30.7, 11.0], [30.8, 11.0], [30.9, 11.0], [31.0, 11.0], [31.1, 11.0], [31.2, 11.0], [31.3, 11.0], [31.4, 11.0], [31.5, 11.0], [31.6, 11.0], [31.7, 11.0], [31.8, 11.0], [31.9, 11.0], [32.0, 11.0], [32.1, 11.0], [32.2, 11.0], [32.3, 11.0], [32.4, 11.0], [32.5, 11.0], [32.6, 11.0], [32.7, 11.0], [32.8, 11.0], [32.9, 11.0], [33.0, 11.0], [33.1, 11.0], [33.2, 11.0], [33.3, 11.0], [33.4, 11.0], [33.5, 11.0], [33.6, 11.0], [33.7, 11.0], [33.8, 12.0], [33.9, 12.0], [34.0, 12.0], [34.1, 12.0], [34.2, 12.0], [34.3, 12.0], [34.4, 12.0], [34.5, 12.0], [34.6, 12.0], [34.7, 12.0], [34.8, 12.0], [34.9, 12.0], [35.0, 12.0], [35.1, 12.0], [35.2, 12.0], [35.3, 12.0], [35.4, 12.0], [35.5, 12.0], [35.6, 12.0], [35.7, 12.0], [35.8, 12.0], [35.9, 12.0], [36.0, 13.0], [36.1, 13.0], [36.2, 13.0], [36.3, 13.0], [36.4, 13.0], [36.5, 13.0], [36.6, 13.0], [36.7, 13.0], [36.8, 13.0], [36.9, 13.0], [37.0, 13.0], [37.1, 13.0], [37.2, 13.0], [37.3, 13.0], [37.4, 13.0], [37.5, 13.0], [37.6, 13.0], [37.7, 13.0], [37.8, 13.0], [37.9, 13.0], [38.0, 13.0], [38.1, 13.0], [38.2, 13.0], [38.3, 13.0], [38.4, 13.0], [38.5, 13.0], [38.6, 13.0], [38.7, 13.0], [38.8, 13.0], [38.9, 13.0], [39.0, 13.0], [39.1, 13.0], [39.2, 13.0], [39.3, 13.0], [39.4, 13.0], [39.5, 14.0], [39.6, 14.0], [39.7, 14.0], [39.8, 14.0], [39.9, 14.0], [40.0, 14.0], [40.1, 14.0], [40.2, 14.0], [40.3, 14.0], [40.4, 14.0], [40.5, 14.0], [40.6, 14.0], [40.7, 14.0], [40.8, 14.0], [40.9, 14.0], [41.0, 14.0], [41.1, 14.0], [41.2, 14.0], [41.3, 14.0], [41.4, 14.0], [41.5, 14.0], [41.6, 14.0], [41.7, 14.0], [41.8, 14.0], [41.9, 14.0], [42.0, 14.0], [42.1, 14.0], [42.2, 14.0], [42.3, 14.0], [42.4, 14.0], [42.5, 14.0], [42.6, 14.0], [42.7, 14.0], [42.8, 15.0], [42.9, 15.0], [43.0, 15.0], [43.1, 15.0], [43.2, 15.0], [43.3, 15.0], [43.4, 15.0], [43.5, 15.0], [43.6, 15.0], [43.7, 15.0], [43.8, 15.0], [43.9, 15.0], [44.0, 15.0], [44.1, 15.0], [44.2, 15.0], [44.3, 15.0], [44.4, 15.0], [44.5, 15.0], [44.6, 15.0], [44.7, 15.0], [44.8, 16.0], [44.9, 16.0], [45.0, 16.0], [45.1, 16.0], [45.2, 16.0], [45.3, 16.0], [45.4, 16.0], [45.5, 16.0], [45.6, 16.0], [45.7, 16.0], [45.8, 16.0], [45.9, 16.0], [46.0, 16.0], [46.1, 17.0], [46.2, 17.0], [46.3, 17.0], [46.4, 17.0], [46.5, 17.0], [46.6, 17.0], [46.7, 17.0], [46.8, 18.0], [46.9, 18.0], [47.0, 18.0], [47.1, 18.0], [47.2, 18.0], [47.3, 18.0], [47.4, 18.0], [47.5, 18.0], [47.6, 18.0], [47.7, 18.0], [47.8, 18.0], [47.9, 18.0], [48.0, 19.0], [48.1, 19.0], [48.2, 19.0], [48.3, 19.0], [48.4, 19.0], [48.5, 20.0], [48.6, 20.0], [48.7, 20.0], [48.8, 21.0], [48.9, 21.0], [49.0, 21.0], [49.1, 22.0], [49.2, 22.0], [49.3, 23.0], [49.4, 23.0], [49.5, 24.0], [49.6, 24.0], [49.7, 24.0], [49.8, 25.0], [49.9, 25.0], [50.0, 25.0], [50.1, 25.0], [50.2, 26.0], [50.3, 26.0], [50.4, 26.0], [50.5, 26.0], [50.6, 26.0], [50.7, 26.0], [50.8, 26.0], [50.9, 27.0], [51.0, 27.0], [51.1, 28.0], [51.2, 28.0], [51.3, 28.0], [51.4, 30.0], [51.5, 31.0], [51.6, 34.0], [51.7, 37.0], [51.8, 37.0], [51.9, 39.0], [52.0, 40.0], [52.1, 44.0], [52.2, 45.0], [52.3, 45.0], [52.4, 46.0], [52.5, 46.0], [52.6, 49.0], [52.7, 49.0], [52.8, 57.0], [52.9, 58.0], [53.0, 60.0], [53.1, 63.0], [53.2, 63.0], [53.3, 68.0], [53.4, 68.0], [53.5, 71.0], [53.6, 73.0], [53.7, 73.0], [53.8, 74.0], [53.9, 74.0], [54.0, 77.0], [54.1, 77.0], [54.2, 82.0], [54.3, 90.0], [54.4, 94.0], [54.5, 95.0], [54.6, 95.0], [54.7, 97.0], [54.8, 98.0], [54.9, 102.0], [55.0, 103.0], [55.1, 111.0], [55.2, 114.0], [55.3, 119.0], [55.4, 121.0], [55.5, 123.0], [55.6, 128.0], [55.7, 129.0], [55.8, 132.0], [55.9, 134.0], [56.0, 143.0], [56.1, 145.0], [56.2, 146.0], [56.3, 149.0], [56.4, 150.0], [56.5, 158.0], [56.6, 162.0], [56.7, 162.0], [56.8, 163.0], [56.9, 166.0], [57.0, 167.0], [57.1, 168.0], [57.2, 171.0], [57.3, 172.0], [57.4, 173.0], [57.5, 175.0], [57.6, 175.0], [57.7, 178.0], [57.8, 179.0], [57.9, 182.0], [58.0, 182.0], [58.1, 186.0], [58.2, 188.0], [58.3, 190.0], [58.4, 192.0], [58.5, 195.0], [58.6, 195.0], [58.7, 196.0], [58.8, 199.0], [58.9, 207.0], [59.0, 216.0], [59.1, 217.0], [59.2, 220.0], [59.3, 227.0], [59.4, 228.0], [59.5, 234.0], [59.6, 239.0], [59.7, 243.0], [59.8, 245.0], [59.9, 247.0], [60.0, 250.0], [60.1, 258.0], [60.2, 264.0], [60.3, 277.0], [60.4, 291.0], [60.5, 298.0], [60.6, 307.0], [60.7, 309.0], [60.8, 315.0], [60.9, 327.0], [61.0, 332.0], [61.1, 335.0], [61.2, 338.0], [61.3, 354.0], [61.4, 358.0], [61.5, 395.0], [61.6, 399.0], [61.7, 402.0], [61.8, 402.0], [61.9, 407.0], [62.0, 412.0], [62.1, 423.0], [62.2, 435.0], [62.3, 439.0], [62.4, 456.0], [62.5, 457.0], [62.6, 458.0], [62.7, 464.0], [62.8, 468.0], [62.9, 470.0], [63.0, 470.0], [63.1, 484.0], [63.2, 496.0], [63.3, 499.0], [63.4, 506.0], [63.5, 507.0], [63.6, 513.0], [63.7, 516.0], [63.8, 525.0], [63.9, 532.0], [64.0, 534.0], [64.1, 536.0], [64.2, 538.0], [64.3, 541.0], [64.4, 576.0], [64.5, 579.0], [64.6, 581.0], [64.7, 598.0], [64.8, 606.0], [64.9, 608.0], [65.0, 609.0], [65.1, 609.0], [65.2, 609.0], [65.3, 614.0], [65.4, 616.0], [65.5, 643.0], [65.6, 652.0], [65.7, 673.0], [65.8, 677.0], [65.9, 678.0], [66.0, 687.0], [66.1, 692.0], [66.2, 703.0], [66.3, 724.0], [66.4, 725.0], [66.5, 729.0], [66.6, 735.0], [66.7, 739.0], [66.8, 745.0], [66.9, 746.0], [67.0, 770.0], [67.1, 776.0], [67.2, 778.0], [67.3, 779.0], [67.4, 801.0], [67.5, 833.0], [67.6, 838.0], [67.7, 844.0], [67.8, 845.0], [67.9, 856.0], [68.0, 858.0], [68.1, 870.0], [68.2, 870.0], [68.3, 885.0], [68.4, 892.0], [68.5, 893.0], [68.6, 905.0], [68.7, 915.0], [68.8, 915.0], [68.9, 923.0], [69.0, 937.0], [69.1, 941.0], [69.2, 945.0], [69.3, 951.0], [69.4, 956.0], [69.5, 956.0], [69.6, 959.0], [69.7, 959.0], [69.8, 963.0], [69.9, 970.0], [70.0, 971.0], [70.1, 983.0], [70.2, 983.0], [70.3, 988.0], [70.4, 991.0], [70.5, 993.0], [70.6, 1009.0], [70.7, 1010.0], [70.8, 1014.0], [70.9, 1016.0], [71.0, 1026.0], [71.1, 1033.0], [71.2, 1045.0], [71.3, 1063.0], [71.4, 1067.0], [71.5, 1072.0], [71.6, 1098.0], [71.7, 1105.0], [71.8, 1110.0], [71.9, 1111.0], [72.0, 1126.0], [72.1, 1137.0], [72.2, 1139.0], [72.3, 1141.0], [72.4, 1143.0], [72.5, 1154.0], [72.6, 1155.0], [72.7, 1160.0], [72.8, 1164.0], [72.9, 1173.0], [73.0, 1173.0], [73.1, 1176.0], [73.2, 1177.0], [73.3, 1191.0], [73.4, 1194.0], [73.5, 1201.0], [73.6, 1202.0], [73.7, 1206.0], [73.8, 1216.0], [73.9, 1229.0], [74.0, 1232.0], [74.1, 1237.0], [74.2, 1238.0], [74.3, 1252.0], [74.4, 1256.0], [74.5, 1260.0], [74.6, 1265.0], [74.7, 1296.0], [74.8, 1297.0], [74.9, 1316.0], [75.0, 1319.0], [75.1, 1334.0], [75.2, 1355.0], [75.3, 1356.0], [75.4, 1380.0], [75.5, 1385.0], [75.6, 1386.0], [75.7, 1411.0], [75.8, 1413.0], [75.9, 1418.0], [76.0, 1423.0], [76.1, 1426.0], [76.2, 1439.0], [76.3, 1445.0], [76.4, 1445.0], [76.5, 1446.0], [76.6, 1448.0], [76.7, 1456.0], [76.8, 1462.0], [76.9, 1463.0], [77.0, 1463.0], [77.1, 1478.0], [77.2, 1483.0], [77.3, 1502.0], [77.4, 1510.0], [77.5, 1514.0], [77.6, 1514.0], [77.7, 1514.0], [77.8, 1515.0], [77.9, 1522.0], [78.0, 1526.0], [78.1, 1531.0], [78.2, 1534.0], [78.3, 1541.0], [78.4, 1559.0], [78.5, 1563.0], [78.6, 1565.0], [78.7, 1582.0], [78.8, 1585.0], [78.9, 1587.0], [79.0, 1599.0], [79.1, 1600.0], [79.2, 1610.0], [79.3, 1622.0], [79.4, 1636.0], [79.5, 1648.0], [79.6, 1648.0], [79.7, 1651.0], [79.8, 1652.0], [79.9, 1655.0], [80.0, 1662.0], [80.1, 1663.0], [80.2, 1675.0], [80.3, 1682.0], [80.4, 1684.0], [80.5, 1689.0], [80.6, 1696.0], [80.7, 1701.0], [80.8, 1723.0], [80.9, 1724.0], [81.0, 1742.0], [81.1, 1743.0], [81.2, 1763.0], [81.3, 1770.0], [81.4, 1780.0], [81.5, 1785.0], [81.6, 1787.0], [81.7, 1791.0], [81.8, 1794.0], [81.9, 1796.0], [82.0, 1805.0], [82.1, 1807.0], [82.2, 1809.0], [82.3, 1810.0], [82.4, 1818.0], [82.5, 1820.0], [82.6, 1824.0], [82.7, 1837.0], [82.8, 1858.0], [82.9, 1871.0], [83.0, 1886.0], [83.1, 1899.0], [83.2, 1902.0], [83.3, 1910.0], [83.4, 1927.0], [83.5, 1934.0], [83.6, 1937.0], [83.7, 1943.0], [83.8, 1943.0], [83.9, 1944.0], [84.0, 1967.0], [84.1, 1979.0], [84.2, 1981.0], [84.3, 1982.0], [84.4, 1984.0], [84.5, 1985.0], [84.6, 1986.0], [84.7, 1992.0], [84.8, 1992.0], [84.9, 1993.0], [85.0, 1995.0], [85.1, 2012.0], [85.2, 2017.0], [85.3, 2020.0], [85.4, 2021.0], [85.5, 2021.0], [85.6, 2025.0], [85.7, 2026.0], [85.8, 2028.0], [85.9, 2028.0], [86.0, 2035.0], [86.1, 2052.0], [86.2, 2055.0], [86.3, 2061.0], [86.4, 2075.0], [86.5, 2080.0], [86.6, 2084.0], [86.7, 2095.0], [86.8, 2097.0], [86.9, 2097.0], [87.0, 2107.0], [87.1, 2123.0], [87.2, 2124.0], [87.3, 2127.0], [87.4, 2129.0], [87.5, 2131.0], [87.6, 2135.0], [87.7, 2136.0], [87.8, 2137.0], [87.9, 2140.0], [88.0, 2148.0], [88.1, 2152.0], [88.2, 2159.0], [88.3, 2165.0], [88.4, 2165.0], [88.5, 2166.0], [88.6, 2176.0], [88.7, 2187.0], [88.8, 2195.0], [88.9, 2196.0], [89.0, 2197.0], [89.1, 2210.0], [89.2, 2215.0], [89.3, 2215.0], [89.4, 2220.0], [89.5, 2221.0], [89.6, 2224.0], [89.7, 2227.0], [89.8, 2228.0], [89.9, 2230.0], [90.0, 2233.0], [90.1, 2239.0], [90.2, 2240.0], [90.3, 2246.0], [90.4, 2255.0], [90.5, 2260.0], [90.6, 2263.0], [90.7, 2269.0], [90.8, 2272.0], [90.9, 2286.0], [91.0, 2305.0], [91.1, 2322.0], [91.2, 2328.0], [91.3, 2330.0], [91.4, 2337.0], [91.5, 2342.0], [91.6, 2366.0], [91.7, 2367.0], [91.8, 2373.0], [91.9, 2376.0], [92.0, 2377.0], [92.1, 2383.0], [92.2, 2386.0], [92.3, 2389.0], [92.4, 2389.0], [92.5, 2392.0], [92.6, 2399.0], [92.7, 2400.0], [92.8, 2402.0], [92.9, 2403.0], [93.0, 2415.0], [93.1, 2419.0], [93.2, 2420.0], [93.3, 2422.0], [93.4, 2425.0], [93.5, 2428.0], [93.6, 2432.0], [93.7, 2435.0], [93.8, 2444.0], [93.9, 2471.0], [94.0, 2475.0], [94.1, 2475.0], [94.2, 2475.0], [94.3, 2487.0], [94.4, 2488.0], [94.5, 2489.0], [94.6, 2495.0], [94.7, 2500.0], [94.8, 2503.0], [94.9, 2522.0], [95.0, 2535.0], [95.1, 2536.0], [95.2, 2553.0], [95.3, 2561.0], [95.4, 2572.0], [95.5, 2577.0], [95.6, 2578.0], [95.7, 2588.0], [95.8, 2601.0], [95.9, 2603.0], [96.0, 2604.0], [96.1, 2618.0], [96.2, 2644.0], [96.3, 2652.0], [96.4, 2674.0], [96.5, 2685.0], [96.6, 2687.0], [96.7, 2691.0], [96.8, 2692.0], [96.9, 2703.0], [97.0, 2723.0], [97.1, 2726.0], [97.2, 2770.0], [97.3, 2784.0], [97.4, 2788.0], [97.5, 2798.0], [97.6, 2801.0], [97.7, 2802.0], [97.8, 2803.0], [97.9, 2813.0], [98.0, 2825.0], [98.1, 2831.0], [98.2, 2833.0], [98.3, 2834.0], [98.4, 2837.0], [98.5, 2839.0], [98.6, 2844.0], [98.7, 2849.0], [98.8, 2850.0], [98.9, 2854.0], [99.0, 2859.0], [99.1, 2863.0], [99.2, 2865.0], [99.3, 2872.0], [99.4, 2925.0], [99.5, 2927.0], [99.6, 2931.0], [99.7, 2986.0], [99.8, 3005.0], [99.9, 3015.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "maxY": 548.0, "series": [{"data": [[0.0, 548.0], [600.0, 14.0], [700.0, 13.0], [800.0, 12.0], [900.0, 20.0], [1000.0, 11.0], [1100.0, 18.0], [1200.0, 14.0], [1300.0, 8.0], [1400.0, 16.0], [1500.0, 18.0], [1600.0, 16.0], [100.0, 40.0], [1700.0, 13.0], [1800.0, 12.0], [1900.0, 19.0], [2000.0, 19.0], [2100.0, 21.0], [2200.0, 19.0], [2300.0, 17.0], [2400.0, 20.0], [2500.0, 11.0], [2600.0, 11.0], [2800.0, 18.0], [2700.0, 7.0], [2900.0, 4.0], [3000.0, 2.0], [200.0, 17.0], [300.0, 11.0], [400.0, 17.0], [500.0, 14.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3000.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 140.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 633.0, "series": [{"data": [[0.0, 633.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 140.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 227.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 1.2051282051282055, "minX": 1.792301975E12, "maxY": 227.7734806629834, "series": [{"data": [[1.792301982E12, 1.2051282051282055], [1.79230198E12, 1.4099999999999997], [1.792301979E12, 3.7821782178217824], [1.792301981E12, 1.3400000000000005], [1.792301977E12, 6.25], [1.792301978E12, 1.8499999999999999], [1.792301976E12, 89.61090909090922], [1.792301975E12, 227.7734806629834]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792301982E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 9.109004739336497, "minX": 1.0, "maxY": 3005.0, "series": [{"data": [[2.0, 12.735294117647067], [3.0, 29.076923076923077], [4.0, 49.42857142857143], [5.0, 71.25], [6.0, 58.833333333333336], [7.0, 147.0], [8.0, 73.16666666666666], [9.0, 232.83333333333334], [10.0, 93.25], [11.0, 133.33333333333334], [12.0, 82.66666666666667], [13.0, 141.0], [14.0, 186.66666666666666], [15.0, 114.6], [16.0, 76.75], [17.0, 160.66666666666666], [18.0, 123.75], [19.0, 208.0], [20.0, 175.0], [21.0, 211.5], [22.0, 376.0], [23.0, 200.0], [24.0, 220.66666666666666], [25.0, 224.75], [26.0, 236.5], [27.0, 240.0], [28.0, 156.0], [29.0, 468.0], [30.0, 77.0], [31.0, 266.0], [33.0, 507.0], [32.0, 217.0], [35.0, 896.0], [34.0, 245.0], [37.0, 358.0], [39.0, 608.0], [38.0, 678.0], [41.0, 399.0], [40.0, 941.0], [42.0, 866.5], [45.0, 614.0], [44.0, 724.5], [47.0, 332.0], [46.0, 2012.0], [49.0, 464.0], [48.0, 678.5], [51.0, 541.0], [50.0, 532.0], [53.0, 1439.0], [52.0, 473.5], [55.0, 740.3333333333334], [54.0, 856.0], [57.0, 688.0], [59.0, 778.0], [58.0, 1937.0], [60.0, 530.0], [63.0, 959.0], [62.0, 715.6666666666666], [67.0, 395.0], [66.0, 1445.0], [65.0, 616.0], [64.0, 1139.0], [71.0, 483.5], [69.0, 828.0], [75.0, 729.0], [74.0, 820.0], [73.0, 568.0], [79.0, 1434.0], [78.0, 247.0], [77.0, 516.0], [76.0, 885.0], [83.0, 676.0], [81.0, 956.0], [80.0, 1478.0], [87.0, 1296.0], [86.0, 752.5], [85.0, 758.5], [84.0, 1675.0], [90.0, 520.5], [88.0, 506.0], [95.0, 2342.0], [94.0, 1902.0], [93.0, 1413.0], [92.0, 1108.5], [99.0, 1265.0], [98.0, 1009.0], [97.0, 775.0], [96.0, 870.0], [103.0, 682.5], [102.0, 402.0], [101.0, 1723.0], [100.0, 1796.0], [107.0, 899.5], [106.0, 803.5], [105.0, 983.0], [104.0, 1016.0], [111.0, 735.0], [110.0, 419.66666666666663], [109.0, 887.0], [108.0, 579.0], [115.0, 945.0], [114.0, 1540.6666666666667], [113.0, 2165.0], [112.0, 746.0], [119.0, 1334.0], [118.0, 1515.0], [117.0, 1599.0], [116.0, 1290.5], [123.0, 1163.5], [122.0, 999.5], [120.0, 1123.0], [127.0, 1444.6666666666667], [126.0, 703.0], [125.0, 845.0], [124.0, 1131.5], [135.0, 2588.0], [134.0, 1576.3333333333333], [132.0, 1696.6666666666667], [131.0, 1163.0], [130.0, 970.0], [129.0, 1701.0], [128.0, 1662.0], [143.0, 1493.25], [142.0, 709.5], [141.0, 2129.0], [140.0, 1409.5], [139.0, 1731.5], [138.0, 1256.0], [137.0, 1610.0], [136.0, 1584.0], [151.0, 1119.5], [150.0, 1807.0], [149.0, 1526.0], [148.0, 743.5], [147.0, 1600.5], [146.0, 1232.0], [145.0, 1110.0], [144.0, 1546.0], [159.0, 2084.0], [158.0, 1386.0], [157.0, 1735.0], [156.0, 2196.0], [155.0, 1697.0], [154.0, 2421.0], [152.0, 1649.25], [153.0, 1202.0], [167.0, 1356.0], [166.0, 1446.5], [165.0, 1726.25], [164.0, 1418.0], [163.0, 1110.0], [162.0, 892.0], [161.0, 1877.0], [160.0, 2432.0], [175.0, 1541.0], [174.0, 1201.0], [173.0, 1563.0], [172.0, 2553.0], [171.0, 1498.5], [169.0, 2129.5], [168.0, 2397.5], [183.0, 1514.0], [182.0, 1901.0], [181.0, 1651.0], [180.0, 1539.0], [179.0, 1505.0], [178.0, 1377.75], [176.0, 2025.0], [191.0, 1756.5], [190.0, 1970.625], [188.0, 1270.5], [187.0, 1639.0], [189.0, 1695.0], [186.0, 1230.0], [185.0, 1492.25], [184.0, 2134.0], [199.0, 1602.0], [197.0, 1982.0], [196.0, 1797.5], [195.0, 1557.0], [194.0, 1575.3333333333333], [192.0, 1967.0], [193.0, 1609.5], [207.0, 2080.0], [206.0, 2101.5], [205.0, 1846.3333333333333], [204.0, 1489.5], [203.0, 1789.25], [202.0, 2136.0], [201.0, 1910.0], [200.0, 1841.5], [215.0, 2118.0], [214.0, 1607.5], [213.0, 3005.0], [212.0, 2061.3333333333335], [211.0, 2342.3333333333335], [210.0, 2126.0], [209.0, 2025.75], [208.0, 2925.0], [222.0, 2215.0], [218.0, 1992.0], [217.0, 2028.0], [216.0, 2148.0], [231.0, 2887.5], [230.0, 2471.0], [229.0, 2272.5], [228.0, 2692.0], [227.0, 2459.3333333333335], [226.0, 2831.0], [225.0, 2625.0], [224.0, 2526.6], [239.0, 2420.0], [238.0, 2779.0], [237.0, 2500.0], [236.0, 2152.0], [235.0, 1871.0], [234.0, 2305.0], [233.0, 2239.0], [232.0, 2403.0], [247.0, 2575.8], [246.0, 1986.0], [245.0, 2025.0], [244.0, 2784.0], [243.0, 2872.0], [242.0, 2392.0], [241.0, 2788.0], [240.0, 2618.0], [255.0, 2228.0], [254.0, 2674.0], [253.0, 2652.0], [252.0, 2536.0], [251.0, 2383.0], [250.0, 2813.0], [249.0, 2475.0], [248.0, 2548.0], [270.0, 2639.0], [271.0, 2246.0], [268.0, 2825.0], [259.0, 2685.0], [258.0, 2454.5], [256.0, 2561.0], [267.0, 2488.0], [266.0, 2174.0], [264.0, 2021.0], [263.0, 2849.0], [262.0, 1984.0], [261.0, 2703.0], [260.0, 2604.0], [286.0, 2601.0], [285.0, 2215.0], [283.0, 2833.0], [282.0, 2337.0], [281.0, 2678.0], [280.0, 2377.0], [278.0, 2210.0], [277.0, 2480.5], [275.0, 2278.5], [273.0, 2312.0], [293.0, 2411.7], [1.0, 9.109004739336497]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[67.40900000000002, 666.7969999999998]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 293.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 14883.0, "minX": 1.792301975E12, "maxY": 133308.0, "series": [{"data": [[1.792301982E12, 18900.0], [1.79230198E12, 48486.0], [1.792301979E12, 48955.0], [1.792301981E12, 48467.0], [1.792301977E12, 50420.0], [1.792301978E12, 48495.0], [1.792301976E12, 133308.0], [1.792301975E12, 87806.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792301982E12, 14883.0], [1.79230198E12, 38186.0], [1.792301979E12, 38552.0], [1.792301981E12, 38167.0], [1.792301977E12, 39708.0], [1.792301978E12, 38195.0], [1.792301976E12, 104983.0], [1.792301975E12, 69163.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792301982E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 9.12820512820513, "minX": 1.792301975E12, "maxY": 2162.767955801106, "series": [{"data": [[1.792301982E12, 9.12820512820513], [1.79230198E12, 10.04], [1.792301979E12, 32.31683168316832], [1.792301981E12, 9.770000000000001], [1.792301977E12, 56.66346153846152], [1.792301978E12, 12.89], [1.792301976E12, 954.7381818181822], [1.792301975E12, 2162.767955801106]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792301982E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 9.12820512820513, "minX": 1.792301975E12, "maxY": 2162.6022099447514, "series": [{"data": [[1.792301982E12, 9.12820512820513], [1.79230198E12, 10.020000000000001], [1.792301979E12, 32.30693069306932], [1.792301981E12, 9.759999999999996], [1.792301977E12, 56.634615384615394], [1.792301978E12, 12.879999999999995], [1.792301976E12, 954.7272727272729], [1.792301975E12, 2162.6022099447514]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792301982E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.2300000000000001, "minX": 1.792301975E12, "maxY": 4.414364640883976, "series": [{"data": [[1.792301982E12, 0.3076923076923077], [1.79230198E12, 0.37], [1.792301979E12, 0.29702970297029696], [1.792301981E12, 0.2300000000000001], [1.792301977E12, 0.3173076923076923], [1.792301978E12, 0.3500000000000002], [1.792301976E12, 0.4654545454545458], [1.792301975E12, 4.414364640883976]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792301982E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 8.0, "minX": 1.792301975E12, "maxY": 3015.0, "series": [{"data": [[1.792301982E12, 12.0], [1.79230198E12, 25.0], [1.792301979E12, 207.0], [1.792301981E12, 25.0], [1.792301977E12, 327.0], [1.792301978E12, 31.0], [1.792301976E12, 2588.0], [1.792301975E12, 3015.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792301982E12, 10.0], [1.79230198E12, 13.0], [1.792301979E12, 117.39999999999995], [1.792301981E12, 11.0], [1.792301977E12, 192.5], [1.792301978E12, 18.0], [1.792301976E12, 2045.6000000000004], [1.792301975E12, 2832.6]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792301982E12, 12.0], [1.79230198E12, 24.929999999999964], [1.792301979E12, 206.70000000000005], [1.792301981E12, 24.93999999999997], [1.792301977E12, 326.40000000000003], [1.792301978E12, 30.95999999999998], [1.792301976E12, 2508.9200000000005], [1.792301975E12, 3006.8]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792301982E12, 11.0], [1.79230198E12, 15.899999999999977], [1.792301979E12, 173.29999999999984], [1.792301981E12, 13.949999999999989], [1.792301977E12, 232.25], [1.792301978E12, 18.94999999999999], [1.792301976E12, 2326.0], [1.792301975E12, 2862.6]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.792301982E12, 8.0], [1.79230198E12, 8.0], [1.792301979E12, 8.0], [1.792301981E12, 8.0], [1.792301977E12, 9.0], [1.792301978E12, 9.0], [1.792301976E12, 11.0], [1.792301975E12, 652.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792301982E12, 9.0], [1.79230198E12, 9.0], [1.792301979E12, 11.0], [1.792301981E12, 9.0], [1.792301977E12, 16.0], [1.792301978E12, 12.0], [1.792301976E12, 892.0], [1.792301975E12, 2195.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792301982E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 9.0, "minX": 39.0, "maxY": 2195.0, "series": [{"data": [[275.0, 892.0], [39.0, 9.0], [181.0, 2195.0], [100.0, 10.0], [101.0, 11.0], [104.0, 16.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 275.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 9.0, "minX": 39.0, "maxY": 2195.0, "series": [{"data": [[275.0, 892.0], [39.0, 9.0], [181.0, 2195.0], [100.0, 10.0], [101.0, 11.0], [104.0, 16.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 275.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 39.0, "minX": 1.792301972E12, "maxY": 100.0, "series": [{"data": [[1.792301972E12, 61.0], [1.792301982E12, 39.0], [1.792301973E12, 100.0], [1.79230198E12, 100.0], [1.792301979E12, 100.0], [1.792301981E12, 100.0], [1.792301977E12, 100.0], [1.792301978E12, 100.0], [1.792301974E12, 100.0], [1.792301976E12, 100.0], [1.792301975E12, 100.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792301982E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 39.0, "minX": 1.792301975E12, "maxY": 275.0, "series": [{"data": [[1.792301982E12, 39.0], [1.79230198E12, 100.0], [1.792301979E12, 101.0], [1.792301981E12, 100.0], [1.792301977E12, 104.0], [1.792301978E12, 100.0], [1.792301976E12, 275.0], [1.792301975E12, 181.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792301982E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 39.0, "minX": 1.792301975E12, "maxY": 275.0, "series": [{"data": [[1.792301982E12, 39.0], [1.79230198E12, 100.0], [1.792301979E12, 101.0], [1.792301981E12, 100.0], [1.792301977E12, 104.0], [1.792301978E12, 100.0], [1.792301976E12, 275.0], [1.792301975E12, 181.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792301982E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 39.0, "minX": 1.792301975E12, "maxY": 275.0, "series": [{"data": [[1.792301982E12, 39.0], [1.79230198E12, 100.0], [1.792301979E12, 101.0], [1.792301981E12, 100.0], [1.792301977E12, 104.0], [1.792301978E12, 100.0], [1.792301976E12, 275.0], [1.792301975E12, 181.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792301982E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

